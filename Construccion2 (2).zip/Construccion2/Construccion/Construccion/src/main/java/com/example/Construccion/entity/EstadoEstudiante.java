package com.example.Construccion.entity;
import java.util.Set;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "Estado_Estudiante")

public class EstadoEstudiante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_estado_estudiante")
    private int idEstadoEstudiante;

    @Column(name = "estado_estudiante")
    private String estadoEstudiante;
}
